# ASSETS

> Berisikan semua asset yang dipakai untuk proses development aplikasi.

## TASK

## OVERVIEW

